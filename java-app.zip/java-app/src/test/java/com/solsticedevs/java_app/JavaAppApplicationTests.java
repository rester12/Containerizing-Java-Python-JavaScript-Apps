package com.solsticedevs.java_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
